# AI-Powered Demand Forecasting and Inventory Optimization System

## Upgrade package

This package contains a more complete Streamlit dashboard (`app.py`) and deployment dependencies (`requirements.txt`). It is designed to be copied into the root of the existing GitHub repository, preserving your trained models, datasets, reports, and forecast CSVs.

## Important project facts

- Cleaned historical data: 1,084,847 rows, 54 stores, 33 product families.
- Selected model in saved evaluation: XGBoost.
- Validation results: MAE 35.6759, RMSE 182.5178, WAPE 14.0428%.
- Seasonal-naive baseline WAPE: 22.7330%.
- The saved forecast is 2014-09-03 through 2014-09-09 because the dataset ends on 2014-09-02.
- Inventory values are simulated; the source data does not include actual stock-on-hand or supplier lead times.

## Expected repository structure

Keep the existing project folders and ensure these paths are present in the repository:

- `dataset/processed/sales_clean.csv`
- `forecasts/demand_forecast_7_days.csv`
- `forecasts/inventory_optimization_recommendations.csv`
- `reports/validated_model_metrics.csv` or `reports/model_comparison.csv`
- `reports/part3_evaluation_summary.json`
- `reports/part4_inventory_summary.json`
- `reports/eda_summary.json`

The app remains usable if some report files are absent, but the related sections will show warnings or reduced information.

## Run locally

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

## Update GitHub from Google Colab

Colab does not automatically sync files to GitHub just because they are in Google Drive. You must commit and push the changes.

### Option A — easiest and safest for this dashboard
1. Download this upgrade ZIP.
2. Open your GitHub repository: `https://github.com/gayatrihatkar/AI-Demand-Forecasting-Dashboard`
3. Upload/replace only `app.py` and `requirements.txt` in the repository root, then commit.
4. Streamlit Community Cloud detects the commit and rebuilds the app. Check the deployment logs if it fails.

### Option B — push from Colab using Git
Run in a Colab cell after mounting Drive and making sure the repo is cloned:

```python
from google.colab import drive
drive.mount('/content/drive')

from pathlib import Path
PROJECT_DIR = Path('/content/drive/MyDrive/AI_Demand_Forecasting_Project')
print(PROJECT_DIR.exists(), list(PROJECT_DIR.iterdir())[:10])
```

If the folder is a Git clone, check:

```python
%cd /content/drive/MyDrive/AI_Demand_Forecasting_Project
!git status
!git remote -v
```

If `git status` says it is not a Git repository, do not run `git init` blindly in your Drive project folder. Clone the existing GitHub repository into a separate location first, then copy only the intended changed files into that clone:

```python
%cd /content
!git clone https://github.com/gayatrihatkar/AI-Demand-Forecasting-Dashboard.git github_project
```

Copy `app.py` and `requirements.txt` into `/content/github_project/` (or copy your other project outputs intentionally), then:

```python
%cd /content/github_project
!git status
!git add app.py requirements.txt
!git commit -m "Upgrade MCA demand forecasting dashboard"
!git push origin main
```

GitHub authentication may require a GitHub token or browser-based authentication. Never paste a personal access token into a notebook you share or commit it to the repository. If the default branch is not `main`, use the branch shown by `git branch --show-current`.

## Before replacing the live app

1. Keep a backup copy of the current `app.py`.
2. Confirm forecast CSVs and reports exist in the repository.
3. Commit the two changed files.
4. Wait for Streamlit Cloud to finish rebuilding.
5. Open the app and test all sections; review **Manage app → Logs** if deployment fails.
6. Do not overwrite or retrain the saved models as part of this dashboard update.

## Model artifact compatibility note

The supplied `.joblib` models currently raise an error when loaded in the analysis environment because a private scikit-learn class referenced by the pickle is unavailable in that environment. This dashboard therefore relies on the saved, validated outputs and does not silently retrain or replace your model. Before enabling live re-prediction, reproduce the training environment/version and verify a successful load and prediction against known validation rows.
